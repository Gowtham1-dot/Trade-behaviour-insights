
# 📊 Trader Behavior vs Bitcoin Market Sentiment

This project analyzes how market sentiment — derived from the Bitcoin Fear & Greed Index — impacts trader behavior on the Hyperliquid platform.

## 📁 Dataset Overview

1. **Historical Trader Data (Hyperliquid)**  
   - Columns: `Account`, `Side`, `Execution Price`, `Closed PnL`, `Size USD`, `Timestamp`, etc.

2. **Fear & Greed Index**  
   - Columns: `date`, `classification` (`Fear`, `Greed`, `Extreme Fear`, etc.)

## 🔍 Objective

- Merge sentiment data with trader execution logs.
- Identify patterns in profitability across sentiment phases.
- Visualize and interpret trader behavior under bullish/bearish conditions.
- Highlight top traders and their sentiment-aware strategies.
- Predict profitability of trades using logistic regression.

## 📈 Key Insights

- **Extreme Greed days yield the highest average PnL**.
- Most trades across all sentiments have a median PnL of ~$0 (scalping/breakeven behavior).
- Top traders adapt differently: some thrive in bearish conditions too.
- Logistic Regression model achieves ~54% accuracy in predicting profitable trades.

## 📂 Files

- `Trader_Sentiment_Insights_FULL.ipynb`: Main notebook with code, visualizations, and prediction model.
- `README.md`: Project summary for GitHub or email submission.

## 📧 Submission

Submit this notebook along with your resume via email:

**Subject:** `Junior Data Scientist – Trader Behavior Insights`  
**To:** `saami@bajarangs.com`, `nagasai@bajarangs.com`, `chetan@bajarangs.com`  
**CC:** `sonika@primetrade.ai`
